"""
Test script for ITD (Interaural Time Difference) paradigm
"""

from paradigms.paradigm_itd import ParadigmITD
from utils.varspec import VarSpec
from utils.paradigm_setup_dialog import ParadigmSetupDialog


def main():
    print("=" * 70)
    print(" INTERAURAL TIME DIFFERENCE (ITD)")
    print("=" * 70)

    params = {
        "inner": VarSpec(
            name="itd_ms",
            data={
                'start': 50.0,
                'step_down_initial': 0.5,
                'step_down_final': 0.7,
                'step_up_initial': 2.0,
                'step_up_final': 1.4,
                'min': 0.01,
                'max': 100.0
            }
        ),
        "outer_1": VarSpec(name="signal_type", data=["tone", "noise"]),
        "outer_2": VarSpec(name="fc", data=[1000])  # Hz; only used for tone trials
    }

    dialog = ParadigmSetupDialog(paradigm_name="ITD", params=params)
    participant_id = dialog.show()

    if participant_id is None:
        print("\nSetup cancelled. Exiting.")
        return

    print(f"\nParticipant: {participant_id}")

    itd = ParadigmITD(params, verbose=True, participant_id=participant_id)

    try:
        itd.main()
        print(f"\n>>> Results saved: {participant_id}_ITD_*.csv")
    except KeyboardInterrupt:
        print("\nTest aborted by user.")
    except Exception as e:
        print(f"\n!!! Error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    main()
