"""
Frequency Modulation (FM) Detection Paradigm

Adaptive threshold detection for frequency modulation in tones.
Measures the smallest FM modulation index a participant can detect.

Adaptive parameter: Modulation index (percent frequency deviation)
Outer variables: Modulation frequency (fm), carrier frequency (fc), amplitude
"""

from paradigms.adaptive_paradigm import AdaptiveParadigm
from trial_player import TrialPlayer
from utils.varspec import VarSpec
import random
import numpy as np


class ParadigmFM(AdaptiveParadigm):
    """
    FM Detection - detect frequency modulation in tones.
    
    Adaptive behavior:
    - Start with detectable FM (e.g., 8% modulation index)
    - Multiplicative steps (halve/double) per Prague protocol
    - Track FM detection threshold for different modulation frequencies
    
    Stimulus: Tone with frequency modulation
    FM formula: f(t) = fc + (fc * mod_ind/100) * sin(2*pi*fm*t)
    where:
        fc = carrier frequency (e.g., 1000 Hz)
        fm = modulation frequency (e.g., 2, 4, 8 Hz)
        mod_ind = modulation index in percent (adaptive parameter)
    """
    
    def __init__(self, params: dict[str, VarSpec], verbose=False, gui_config=None, participant_id=None):
        """
        Initialize FM paradigm.
        
        Args:
            params: Must include "inner" for mod_ind and "outer_*" for fm, fc, etc.
            verbose: Print debug info
            gui_config: Optional GUI customization (uses good defaults if None)
        """
        # Set up GUI config if not provided
        if gui_config is None:
            gui_config = {
                'question': "Did you hear FREQUENCY MODULATION (warbling)?",
                'options': ['No FM (0)', 'Heard FM (1)'],
                'keys': ['0', '1'],
                'window_title': "FM Detection Test",
                'font_size': 16
            }
        
        # Call parent constructor
        # CRITICAL: Set paradigm code BEFORE calling super().__init__()
        self.paradigm_code = 'FM'

        super().__init__(params, verbose=verbose, gui_config=gui_config, participant_id=participant_id)
        
        # FM-specific settings
        self.sample_accurate = False  # Not needed for FM (unlike GAP)
        self.fade_time = 0.05         # Standard fade time
        self.trial_dur = 2.0          # 2 second tone per Prague protocol
        
        # Track last two presented modulation indices for midpoint calculation
        self.last_two_levels = []
    
    def initialize_adaptive_param(self):
        """
        Set initial modulation index from inner variable config with randomization.
        
        Per MultiThreshold protocol:
        - Start mod_ind is randomized within a range
        - For multiplicative params, randomize in log space
        """
        if isinstance(self.inner_var.data, dict):
            base_start = self.inner_var.data.get('start', 8.0)  # Default 8%
            
            # For multiplicative parameters, randomize in log space
            # This means randomizing the ratio rather than absolute value
            randomize_factor = self.inner_var.data.get('randomize_factor', 1.5)  # e.g., 1.5x or /1.5
            
            # Random multiplier between 1/factor and factor
            multiplier = random.uniform(1.0/randomize_factor, randomize_factor)
            randomized_start = base_start * multiplier
            
            # Clip to valid range
            min_mod = self.inner_var.data.get('min', 0.5)    # 0.5%
            max_mod = self.inner_var.data.get('max', 32.0)   # 32%
            self.mod_ind = max(min_mod, min(max_mod, randomized_start))
            
            if self.verbose:
                print(f"Initial modulation index: {self.mod_ind:.2f}%")
                print(f"  (base: {base_start:.2f}%, multiplier: {multiplier:.2f}x, range: {1/randomize_factor:.2f}x to {randomize_factor:.2f}x)")
        else:
            self.mod_ind = 8.0  # Default 8%
            if self.verbose:
                print(f"Initial modulation index: {self.mod_ind:.2f}%")
        
        # Reset tracking
        self.last_two_levels = []
    
    def prepare_trial(self):
        """
        Configure trial: tone with FM at current adaptive modulation index.
        
        For catch trials: pure tone (no FM, mod_ind = 0)
        For normal trials: FM tone with adaptive mod_ind
        """
        self.trial_num += 1
        
        # Determine modulation index based on catch trial status
        if self.is_catch_trial:
            # Catch trial: pure tone (no modulation)
            mod_ind = 0.0
            if self.verbose:
                print(f"  -> Catch trial (pure tone, no FM)")
        else:
            # Normal trial: FM tone
            mod_ind = self.mod_ind
            
            # Track this presented level for midpoint calculation
            self.last_two_levels.append(self.mod_ind)
            if len(self.last_two_levels) > 2:
                self.last_two_levels.pop(0)  # Keep only last 2
            
            if self.verbose:
                fc_str = f"{self.fc:.0f} Hz" if hasattr(self, 'fc') else "?"
                fm_str = f"{self.fm:.1f} Hz" if hasattr(self, 'fm') else "?"
                print(f"  -> Normal trial: mod_ind = {mod_ind:.2f}%, fm = {fm_str}, fc = {fc_str}")
        
        # Configure trial using TrialPlayer
        tone_amp = self.tone_amp if hasattr(self, 'tone_amp') else 0.5
        fc = self.fc if hasattr(self, 'fc') else 1000.0
        fm = self.fm if hasattr(self, 'fm') else 4.0
        self.tp.new_trial(
            wave_type="fm",              # Frequency modulated tone
            durations=self.trial_dur,    # 2 sec per Prague protocol
            fc=fc,                       # Carrier frequency (from outer var, default 1000 Hz)
            fm=fm,                       # Modulation frequency (from outer var, default 4 Hz)
            mod_ind=mod_ind,             # Modulation index (adaptive parameter)
            amp=tone_amp,                # Amplitude (from outer var or default 0.5)
            fade_time=self.fade_time,
            sample_accurate=False,
            verbose=False
        )
    
    def adapt_difficulty(self, direction):
        """
        Adjust modulation index to make detection harder or easier.
        
        Harder: Decrease mod_ind (less frequency deviation = harder to detect)
        Easier: Increase mod_ind (more frequency deviation = easier to detect)
        
        Uses MULTIPLICATIVE steps (halve/double) per Prague protocol.
        Note: This is different from PTA/GAP which use linear steps!
        """
        # Get step factors from config or use Prague defaults
        if isinstance(self.inner_var.data, dict):
            # Prague protocol uses halve/double throughout
            # But we can allow different factors before/after first reversal
            if self.total_num_reversals == 0:
                step_down_factor = self.inner_var.data.get('step_down_initial', 0.5)   # Halve
                step_up_factor = self.inner_var.data.get('step_up_initial', 2.0)       # Double
            else:
                step_down_factor = self.inner_var.data.get('step_down_final', 0.5)     # Halve
                step_up_factor = self.inner_var.data.get('step_up_final', 2.0)         # Double
            
            min_mod = self.inner_var.data.get('min', 0.5)    # 0.5%
            max_mod = self.inner_var.data.get('max', 32.0)   # 32%
        else:
            # Fallback to Prague defaults (halve/double)
            step_down_factor = 0.5
            step_up_factor = 2.0
            min_mod = 0.5
            max_mod = 32.0
        
        # Adjust modulation index (MULTIPLICATIVE steps)
        if direction == "harder":
            self.mod_ind *= step_down_factor  # Smaller mod_ind (e.g., 8% -> 4%)
            self.mod_ind = max(self.mod_ind, min_mod)  # Floor
            if self.verbose:
                print(f"  -> Harder: {self.mod_ind:.2f}% (factor: {step_down_factor}x)")
        
        elif direction == "easier":
            self.mod_ind *= step_up_factor    # Larger mod_ind (e.g., 4% -> 8%)
            self.mod_ind = min(self.mod_ind, max_mod)  # Ceiling
            if self.verbose:
                print(f"  -> Easier: {self.mod_ind:.2f}% (factor: {step_up_factor}x)")
    
    def reset_to_midpoint_mod_ind(self):
        """
        Reset modulation index to midpoint between last two presented levels.
        Called after first reversal as per MultiThreshold protocol.
        
        For multiplicative parameters, midpoint is GEOMETRIC MEAN (not arithmetic).
        """
        if len(self.last_two_levels) == 2:
            # Geometric mean for multiplicative parameters
            # sqrt(a * b) instead of (a + b) / 2
            midpoint = np.sqrt(self.last_two_levels[0] * self.last_two_levels[1])
            self.mod_ind = midpoint
            
            if self.verbose:
                print(f"  -> Reset to midpoint: {midpoint:.2f}%")
                print(f"     (geometric mean of {self.last_two_levels[0]:.2f}% and {self.last_two_levels[1]:.2f}%)")
        else:
            if self.verbose:
                print(f"  -> Warning: Cannot reset to midpoint (need 2 levels, have {len(self.last_two_levels)})")
    
    def update_trial_params(self):
        """
        Override to handle midpoint reset after first reversal.
        """
        # Handle midpoint reset if flagged
        if self.reset_to_midpoint:
            self.reset_to_midpoint_mod_ind()
            self.reset_to_midpoint = False
            
            # Clear difficulty adjustment flags since we just reset to midpoint
            self.make_harder = False
            self.make_easier = False
        
        # Call parent implementation for normal difficulty adjustment
        super().update_trial_params()
    
    def get_log_data(self):
        """
        Return FM-specific data for CSV logging.
        
        Returns column names matching the actual parameter names from VarSpec:
        - mod_ind: Adaptive modulation index in percent (inner variable)
        - fm: Modulation frequency in Hz (outer variable 1)
        - fc: Carrier frequency in Hz (outer variable 2, if present)
        - tone_amp: Tone amplitude (outer variable 3, if present)
        
        Note: All values in their natural units (%, Hz)
        """
        log_dict = {
            "mod_ind": self.mod_ind  # Modulation index in percent
        }
        
        # Add modulation frequency (should always be present)
        if hasattr(self, 'fm'):
            log_dict["fm"] = self.fm
        
        # Add carrier frequency if it exists as an outer variable
        if hasattr(self, 'fc'):
            log_dict["fc"] = self.fc
        
        # Add tone amplitude if it exists
        if hasattr(self, 'tone_amp'):
            log_dict["tone_amp"] = self.tone_amp
        
        return log_dict
    
    def get_trial_description(self):
        """
        Return description for GUI display.
        
        Returns:
            String like "Config 2/5 (fm=4 Hz), Trial 8"
        """
        fm_desc = f"fm={self.fm:.0f} Hz" if hasattr(self, 'fm') else "FM"
        return f"Config {self.config_num}/{self.total_num_configs} ({fm_desc}), Trial {self.trial_num}"


# Example usage and testing
if __name__ == "__main__":
    print("=" * 60)
    print("FM Detection Paradigm Test")
    print("=" * 60)
    
    # Define parameters with multiplicative step factors
    params = {
        "inner": VarSpec(
            name="mod_ind",
            data={
                'start': 8.0,                # Start at 8% modulation
                'step_down_initial': 0.5,    # Halve before first reversal
                'step_down_final': 0.5,      # Halve after first reversal
                'step_up_initial': 2.0,      # Double before first reversal
                'step_up_final': 2.0,        # Double after first reversal
                'min': 0.5,                  # Minimum 0.5%
                'max': 32.0,                 # Maximum 32%
                'randomize_factor': 1.5      # Randomize start by 1.5x or /1.5
            }
        ),
        "outer_1": VarSpec(
            name="fm",
            data=[8, 4, 2]  # Modulation frequencies per Prague protocol
        ),
        "outer_2": VarSpec(
            name="fc",
            data=[1000]  # Carrier frequency (1 kHz)
        ),
        "outer_3": VarSpec(
            name="tone_amp",
            data=[0.5]  # Tone amplitude
        )
    }
    
    # Create and run paradigm
    fm = ParadigmFM(params, verbose=True)
    
    print("\nStarting FM paradigm...")
    print(f"Testing {fm.total_num_configs} configurations")
    print("\nPress Ctrl+C to abort\n")
    
    try:
        fm.main()
    except KeyboardInterrupt:
        print("\n\nTest aborted by user")
        if len(fm.data) > 0:
            print("\nPartial results:")
            print(fm.data)
