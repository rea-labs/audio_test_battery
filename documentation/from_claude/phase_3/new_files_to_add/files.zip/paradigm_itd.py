"""
Interaural Time Difference (ITD) Paradigm

Adaptive threshold detection for timing differences between ears.
Measures the smallest time delay between left and right ears that 
can be lateralized (heard as coming from one side).

Adaptive parameter: ITD (milliseconds) - time delay between ears
Outer variables: Carrier frequency (fc), signal type (tone/noise), reference level

NOTE: ITD requires sample-accurate stereo generation for microsecond precision.
"""

from paradigms.adaptive_paradigm import AdaptiveParadigm
from trial_player import TrialPlayer
from utils.varspec import VarSpec
import random
import numpy as np
from psychopy import sound


class ParadigmITD(AdaptiveParadigm):
    """
    ITD Detection - detect interaural time differences (spatial hearing cue).
    
    Adaptive behavior:
    - Start with easily detectable ITD (e.g., 10 ms)
    - Multiplicative steps (halve/double) initially, smaller steps after reversal
    - Track ITD threshold for different frequencies and signal types
    
    Stimulus: Tone or noise with time delay between ears
    Task: "Which side did the sound come from: Left, Right, or Center?"
    
    ITD creates perception of sound location:
    - Positive ITD Ã¢â€ â€™ sound from right (right ear delayed)
    - Negative ITD Ã¢â€ â€™ sound from left (left ear delayed)
    - Zero ITD Ã¢â€ â€™ sound from center (simultaneous)
    
    NOTE: ITD is most effective for low frequencies (<1500 Hz) and broadband noise.
    """
    
    def __init__(self, params: dict[str, VarSpec], verbose=False, gui_config=None, participant_id=None):
        """
        Initialize ITD paradigm.
        
        Args:
            params: Must include "inner" for itd_ms and "outer_*" for fc, signal_type, etc.
            verbose: Print debug info
            gui_config: Optional GUI customization
        """
        if gui_config is None:
            gui_config = {
                'question': "Which SIDE did the sound come from?",
                'options': ['Equal/Center (0)', 'Left (1)', 'Right (2)'],
                'keys': ['0', '1', '2'],
                'window_title': "ITD Test - Interaural Time Difference",
                'font_size': 16
            }
        
        # CRITICAL: Set paradigm code BEFORE calling super().__init__()
        self.paradigm_code = 'ITD'

        super().__init__(params, verbose=verbose, gui_config=gui_config, participant_id=participant_id)
        
        # ITD-specific settings
        self.sample_accurate = True   # CRITICAL: Required for precise timing
        self.fade_time = 0.05
        self.tone_dur = 0.5           # 500 ms
        
        # Track which side leads (for response checking)
        self.leading_side = None  # 0 (left), 1 (center), or 2 (right)
        
        # Track last two presented ITDs for midpoint
        self.last_two_levels = []
        
        # Sample rate for precise timing
        self.fs = 48000  # Hz
    
    def initialize_adaptive_param(self):
        """Set initial ITD from inner variable config with randomization."""
        if isinstance(self.inner_var.data, dict):
            base_start = self.inner_var.data.get('start', 50.0)  # Default 50 ms (very easy start)
            randomize_factor = self.inner_var.data.get('randomize_factor', 1.5)
            
            multiplier = random.uniform(1.0/randomize_factor, randomize_factor)
            randomized_start = base_start * multiplier
            
            min_itd = self.inner_var.data.get('min', 0.01)   # 0.01 ms = 10 ÃŽÂ¼s (human threshold)
            max_itd = self.inner_var.data.get('max', 50.0)   # 50 ms
            self.itd_ms = max(min_itd, min(max_itd, randomized_start))
            
            if self.verbose:
                print(f"Initial ITD: {self.itd_ms:.3f} ms ({self.itd_ms*1000:.1f} ÃŽÂ¼s)")
        else:
            self.itd_ms = 50.0
            if self.verbose:
                print(f"Initial ITD: {self.itd_ms:.3f} ms")
        
        self.last_two_levels = []
    
    def create_itd_stereo(self, mono_wave, itd_ms, fs):
        """
        Create stereo waveform with precise ITD using sample-accurate delays.
        
        Args:
            mono_wave: 1D numpy array (mono signal)
            itd_ms: ITD in milliseconds (positive = right delayed, negative = left delayed)
            fs: Sample rate (Hz)
        
        Returns:
            2D numpy array (NÃƒâ€”2) with precise interaural delay
        """
        itd_seconds = itd_ms / 1000.0
        delay_samples = int(abs(itd_seconds) * fs)
        
        if itd_ms > 0:
            # Positive ITD: right ear delayed (sound from left)
            left = mono_wave
            # Pad right channel with zeros at start, trim at end
            right = np.pad(mono_wave, (delay_samples, 0), mode='constant')[:-delay_samples] if delay_samples > 0 else mono_wave
        elif itd_ms < 0:
            # Negative ITD: left ear delayed (sound from right)
            right = mono_wave
            left = np.pad(mono_wave, (delay_samples, 0), mode='constant')[:-delay_samples] if delay_samples > 0 else mono_wave
        else:
            # Zero ITD: both ears simultaneous
            left = mono_wave
            right = mono_wave
        
        # Stack into stereo (NÃƒâ€”2)
        stereo = np.column_stack([left, right])
        return stereo
    
    def prepare_trial(self):
        """
        Configure trial: tone/noise with ITD between ears.
        
        For catch trials: zero ITD (center)
        For normal trials: one ear randomly leads
        
        Uses sample-accurate stereo generation for precise timing.
        """
        self.trial_num += 1
        
        # Get signal type (sin or white noise)
        signal_type = self.signal_type if hasattr(self, 'signal_type') else 'sin'
        ref_level = self.ref_level if hasattr(self, 'ref_level') else 0.3
        
        if self.is_catch_trial:
            # Catch trial: zero ITD (center)
            itd_val = 0.0
            self.leading_side = 0  # Correct answer: "Equal/Center"
            
            if self.verbose:
                print(f"  -> Catch trial (center: ITD=0 ms)")
        
        else:
            # Normal trial: create ITD by delaying one ear
            # Randomly choose which ear leads (arrives first)
            if random.choice([True, False]):
                # Left ear leads (right delayed) Ã¢â€ â€™ sound from left
                itd_val = self.itd_ms  # Positive ITD
                self.leading_side = 1  # Correct answer: "Left"
            else:
                # Right ear leads (left delayed) Ã¢â€ â€™ sound from right
                itd_val = -self.itd_ms  # Negative ITD
                self.leading_side = 2  # Correct answer: "Right"
            
            # Track this level
            self.last_two_levels.append(self.itd_ms)
            if len(self.last_two_levels) > 2:
                self.last_two_levels.pop(0)
            
            if self.verbose:
                side_name = "LEFT" if self.leading_side == 1 else "RIGHT"
                print(f"  -> Normal trial: ITD = {self.itd_ms:.3f} ms, from {side_name}")
        
        # Generate mono signal
        if signal_type == 'sin':
            # Generate sine tone
            t = np.arange(0, self.tone_dur, 1/self.fs)
            mono_wave = ref_level * np.sin(2 * np.pi * self.fc * t)
            
            # Apply fades
            fade_samples = int(self.fade_time * self.fs)
            fade_window = np.hanning(2 * fade_samples)
            mono_wave[:fade_samples] *= fade_window[:fade_samples]
            mono_wave[-fade_samples:] *= fade_window[-fade_samples:]
            
        elif signal_type == 'white':
            # Generate white noise
            n_samples = int(self.tone_dur * self.fs)
            mono_wave = ref_level * np.random.uniform(-1, 1, n_samples)
            
            # Apply fades
            fade_samples = int(self.fade_time * self.fs)
            fade_window = np.hanning(2 * fade_samples)
            mono_wave[:fade_samples] *= fade_window[:fade_samples]
            mono_wave[-fade_samples:] *= fade_window[-fade_samples:]
        
        # Create stereo with ITD
        stereo_wave = self.create_itd_stereo(mono_wave, itd_val, self.fs)
        
        # Create PsychoPy Sound object directly
        sound_obj = sound.Sound(
            value=stereo_wave,
            sampleRate=self.fs,
            stereo=True,
            secs=self.tone_dur,
            hamming=False
        )
        
        # Store for playback (bypassing TrialPlayer's normal sound generation)
        self.itd_sound = sound_obj
    
    def execute_trial(self):
        """Override to play ITD sound directly (bypassing TrialPlayer)."""
        self.trial_repeats += 1
        
        if self.verbose:
            print(f"Playing ITD sound (trial repeat {self.trial_repeats})...")
        
        # Play the ITD sound directly
        self.itd_sound.play()
        
        # Wait for sound to finish
        import time
        time.sleep(self.tone_dur + 0.1)
    
    def check_answer(self):
        """
        Override to handle 3-response format (left/center/right).
        """
        if self.user_input == "repeat":
            return
        
        response = int(self.user_input)
        
        if self.is_catch_trial:
            if response == 0:  # Equal/Center
                self.correct_answer = 'TN'
            else:
                self.correct_answer = 'FP'
        else:
            if response == self.leading_side:
                self.correct_answer = 'TP'
            else:
                self.correct_answer = 'FN'
        
        if self.verbose:
            side_names = ['Equal/Center', 'Left', 'Right']
            print(f"User: {side_names[response]}, Correct: {side_names[self.leading_side]}, Class: {self.correct_answer}")
    
    def adapt_difficulty(self, direction):
        """Adjust ITD (multiplicative steps)."""
        if isinstance(self.inner_var.data, dict):
            # Use different step sizes before/after first reversal
            if self.total_num_reversals == 0:
                step_down_factor = self.inner_var.data.get('step_down_initial', 0.5)   # Halve
                step_up_factor = self.inner_var.data.get('step_up_initial', 2.0)       # Double
            else:
                # Smaller steps after first reversal for fine resolution
                step_down_factor = self.inner_var.data.get('step_down_final', 0.7)     # Smaller decrease
                step_up_factor = self.inner_var.data.get('step_up_final', 1.4)         # Smaller increase
            
            min_itd = self.inner_var.data.get('min', 0.01)   # 10 ÃŽÂ¼s
            max_itd = self.inner_var.data.get('max', 50.0)
        else:
            step_down_factor = 0.5 if self.total_num_reversals == 0 else 0.7
            step_up_factor = 2.0 if self.total_num_reversals == 0 else 1.4
            min_itd = 0.01
            max_itd = 50.0
        
        if direction == "harder":
            self.itd_ms *= step_down_factor
            self.itd_ms = max(self.itd_ms, min_itd)
            if self.verbose:
                print(f"  -> Harder: {self.itd_ms:.3f} ms ({self.itd_ms*1000:.1f} ÃŽÂ¼s)")
        elif direction == "easier":
            self.itd_ms *= step_up_factor
            self.itd_ms = min(self.itd_ms, max_itd)
            if self.verbose:
                print(f"  -> Easier: {self.itd_ms:.3f} ms ({self.itd_ms*1000:.1f} ÃŽÂ¼s)")
    
    def reset_to_midpoint_itd(self):
        """Reset ITD to geometric mean."""
        if len(self.last_two_levels) == 2:
            midpoint = np.sqrt(self.last_two_levels[0] * self.last_two_levels[1])
            self.itd_ms = midpoint
            if self.verbose:
                print(f"  -> Reset to midpoint: {midpoint:.3f} ms")
    
    def update_trial_params(self):
        """Override to handle midpoint reset."""
        if self.reset_to_midpoint:
            self.reset_to_midpoint_itd()
            self.reset_to_midpoint = False
            self.make_harder = False
            self.make_easier = False
        super().update_trial_params()
    
    def get_log_data(self):
        """Return ITD-specific data for CSV logging."""
        log_dict = {
            "itd_ms": self.itd_ms,
            "itd_us": self.itd_ms * 1000,  # Also log in microseconds
            "leading_side": self.leading_side
        }
        
        if hasattr(self, 'fc'):
            log_dict["fc"] = self.fc
        if hasattr(self, 'signal_type'):
            log_dict["signal_type"] = self.signal_type
        if hasattr(self, 'ref_level'):
            log_dict["ref_level"] = self.ref_level
        
        return log_dict
    
    def get_trial_description(self):
        """Return description for GUI display."""
        if hasattr(self, 'signal_type') and self.signal_type == 'white':
            desc = "White Noise"
        elif hasattr(self, 'fc'):
            desc = f"{self.fc:.0f} Hz"
        else:
            desc = "ITD"
        
        return f"Config {self.config_num}/{self.total_num_configs} ({desc}), Trial {self.trial_num}"


# Example usage
if __name__ == "__main__":
    print("=" * 60)
    print("ITD Detection Paradigm Test")
    print("=" * 60)
    
    # Test with 1 kHz tone and white noise
    params = {
        "inner": VarSpec(
            name="itd_ms",
            data={
                'start': 10.0,               # 10 ms (very detectable)
                'step_down_initial': 0.5,    # Halve before first reversal
                'step_down_final': 0.7,      # Smaller steps after
                'step_up_initial': 2.0,      # Double before first reversal
                'step_up_final': 1.4,        # Smaller steps after
                'min': 0.01,                 # 10 ÃŽÂ¼s (human threshold)
                'max': 50.0,                 # 50 ms
                'randomize_factor': 1.5
            }
        ),
        "outer_1": VarSpec(
            name="signal_type",
            data=['sin', 'white']  # Test both tone and noise
        ),
        "outer_2": VarSpec(
            name="fc",
            data=[1000]  # 1 kHz (for tone trials)
        ),
        "outer_3": VarSpec(
            name="ref_level",
            data=[0.3]
        )
    }
    
    itd = ParadigmITD(params, verbose=True)
    
    print("\nStarting ITD paradigm...")
    print(f"Testing {itd.total_num_configs} configurations")
    print("\nPress Ctrl+C to abort\n")
    
    try:
        itd.main()
    except KeyboardInterrupt:
        print("\n\nTest aborted")
