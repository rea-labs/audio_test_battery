"""
LDL (Loudness Discomfort Level) Paradigm

Measures the level at which pure tones become uncomfortably loud.

This is NOT an adaptive threshold-tracking paradigm. The level simply
increases by a fixed dB step on every trial. The run ends as soon as
the participant reports "uncomfortable". The LDL is the amplitude at
that point.

No catch trials. No reversals. No psychometric fitting.
One run per frequency.

Based on:
  - MultiThreshold toolbox section 5.4 "discomfort"
  - PROLACTIN paradigm plan (frequencies: 500, 1000, 2000, 4000, 8000 Hz)
"""

import tkinter as tk
import numpy as np
import pandas as pd
import time
from pathlib import Path
from datetime import datetime

from trial_player import TrialPlayer


# Response codes (also used as column values in CSV)
COMFORTABLE   = 0
LOUD          = 1
UNCOMFORTABLE = 2

RESPONSE_LABELS = {
    COMFORTABLE:   "Comfortable",
    LOUD:          "Loud",
    UNCOMFORTABLE: "Uncomfortable",
}


class ParadigmLDL:
    """
    LDL - measure loudness discomfort level.

    Stimulus: 500 ms pure tone, level increases by step_dB on every trial.

    Task: "Is the tone comfortable, loud, or uncomfortable?"
    Responses:
      0 = Comfortable  (continue, raise level)
      1 = Loud         (continue, raise level)
      2 = Uncomfortable (stop this run, record LDL)

    One run per frequency. Runs are presented in the order given in
    `frequencies`. The LDL for each frequency is the amplitude at the
    trial where "uncomfortable" was first reported.
    """

    paradigm_code = "LDL"

    def __init__(self,
                 frequencies,
                 start_amp         = 0.2,
                 step_dB           = 3.0,
                 max_amp           = 0.9,
                 tone_dur          = 0.5,
                 fade_time         = 0.004,
                 inter_trial_delay = 0.5,
                 fs                = 44100,
                 participant_id    = "P000",
                 verbose           = False,
                 gui_config        = None):
        """
        Args:
            frequencies:       List of frequencies in Hz, one run per frequency.
            start_amp:         Starting amplitude (linear, 0-1). Default 0.2.
            step_dB:           Level increase per trial in dB. Default 3 dB.
            max_amp:           Hard safety ceiling - run aborts if reached.
                               Default 0.9. Never set above 1.0.
            tone_dur:          Pure tone duration in seconds. Default 0.5 s.
            fade_time:         Onset/offset ramp in seconds. Default 4 ms.
            inter_trial_delay: Pause after response before next tone (seconds).
                               GUI shows "Get ready..." during this time.
                               Default 0.5 s.
            fs:                Sample rate. Default 44100 Hz.
            participant_id:    Used in output filename.
            verbose:           Print trial-by-trial info.
            gui_config:        Optional dict to override GUI defaults.
        """
        if max_amp >= 1.0:
            raise ValueError("max_amp must be < 1.0 to avoid clipping.")

        self.frequencies        = list(frequencies)
        self.start_amp          = float(start_amp)
        self.step_dB            = float(step_dB)
        self.step_mult          = TrialPlayer.db2amp(step_dB)   # multiplicative step
        self.max_amp            = float(max_amp)
        self.tone_dur           = float(tone_dur)
        self.fade_time          = float(fade_time)
        self.inter_trial_delay  = float(inter_trial_delay)
        self.fs                 = int(fs)
        self.participant_id     = participant_id
        self.verbose            = verbose

        # GUI defaults
        _defaults = {
            "question":       "Is the tone comfortable, loud, or uncomfortable?",
            "options":        ["Comfortable (1)", "Loud (2)", "Uncomfortable (3)"],
            "keys":           ["1", "2", "3"],
            "window_title":   "LDL Test - Loudness Discomfort Level",
            "window_geometry": "600x300",
            "font_size":      14,
        }
        self.gui_config = _defaults
        if gui_config:
            self.gui_config.update(gui_config)

        # Data storage: one row per trial across all frequencies
        self.trial_rows = []

        # Summary: one row per frequency (the LDL result)
        self.ldl_results = {}   # {freq: amp_at_uncomfortable}

        # GUI state
        self.root = None

    # ------------------------------------------------------------------ #
    #  Main entry point                                                    #
    # ------------------------------------------------------------------ #

    def main(self):
        """Run all frequencies in order, then save data."""
        self._open_gui()

        try:
            for i, freq in enumerate(self.frequencies):
                self._run_frequency(freq)
                # Pause between runs (skip after the last frequency)
                if i < len(self.frequencies) - 1:
                    self._update_gui_get_ready()
                    time.sleep(self.inter_trial_delay * 2)
        finally:
            self._close_gui()

        self._print_summary()
        self.write_data_to_disk()

    # ------------------------------------------------------------------ #
    #  Single-frequency run                                                #
    # ------------------------------------------------------------------ #

    def _run_frequency(self, freq):
        """
        Present tones at increasing levels for one frequency.
        Stops when participant says "uncomfortable" or max_amp is reached.
        """
        amp      = self.start_amp
        trial_num = 0

        if self.verbose:
            print("\n" + "=" * 50)
            print(f"Starting frequency: {freq} Hz  (start amp={amp:.4f}, "
                  f"step={self.step_dB} dB x{self.step_mult:.4f})")
            print("=" * 50)

        tp = TrialPlayer(fs=self.fs)

        while amp <= self.max_amp:
            trial_num += 1

            if self.verbose:
                print(f"  Trial {trial_num}: {freq} Hz @ amp={amp:.4f} "
                      f"({TrialPlayer.amp2db(amp):.1f} dB rel)")

            # Play tone
            self._update_gui_playing()
            tp.new_trial(
                wave_type="sin",
                durations=self.tone_dur,
                fc=freq,
                amp=amp,
                fade_time=self.fade_time,
                play_now=True,
                verbose=False
            )

            # Collect response
            self._update_gui_waiting()
            response = self._get_response()

            if self.verbose:
                print(f"  -> Response: {RESPONSE_LABELS[response]}")

            # Inter-trial delay with "Get ready..." display
            if response != UNCOMFORTABLE and self.inter_trial_delay > 0:
                self._update_gui_get_ready()
                time.sleep(self.inter_trial_delay)

            # Log this trial
            self.trial_rows.append({
                "unix_time":  datetime.now().timestamp(),
                "freq":       freq,
                "trial_num":  trial_num,
                "amplitude":  amp,
                "amp_dB_rel": round(TrialPlayer.amp2db(amp), 2),
                "response":   response,
                "response_label": RESPONSE_LABELS[response],
            })

            if response == UNCOMFORTABLE:
                # Record LDL and move to next frequency
                self.ldl_results[freq] = amp
                if self.verbose:
                    print(f"  LDL at {freq} Hz: {amp:.4f} "
                          f"({TrialPlayer.amp2db(amp):.1f} dB rel)")
                return

            # Raise level for next trial
            amp = min(amp * self.step_mult, self.max_amp)

        # Reached max_amp without uncomfortable response
        print(f"WARNING: Reached max amplitude ({self.max_amp}) at {freq} Hz "
              f"without uncomfortable response. LDL recorded as max_amp.")
        self.ldl_results[freq] = self.max_amp

    # ------------------------------------------------------------------ #
    #  GUI                                                                 #
    # ------------------------------------------------------------------ #

    def _open_gui(self):
        """Create the persistent response window."""
        self.root = tk.Tk()
        self.root.title(self.gui_config["window_title"])
        self.root.geometry(self.gui_config["window_geometry"])
        self.root.resizable(False, False)

        # Question label (text updated each trial)
        self.question_label = tk.Label(
            self.root,
            text="",
            font=("Arial", self.gui_config["font_size"]),
            wraplength=550,
            pady=20
        )
        self.question_label.pack()

        # Button frame
        self.button_frame = tk.Frame(self.root)
        self.button_frame.pack(pady=20)

        self._update_gui_playing()   # disable buttons initially

    def _update_gui_playing(self):
        """Show 'playing...' state - buttons disabled."""
        if self.root is None:
            return
        self.question_label.config(text="Playing stimulus...")
        # Destroy and rebuild buttons (simplest way to reliably enable/disable)
        for w in self.button_frame.winfo_children():
            w.destroy()
        self.root.update()

    def _update_gui_get_ready(self):
        """Show 'Get ready...' between response and next tone."""
        if self.root is None:
            return
        self.question_label.config(text="Get ready...")
        for w in self.button_frame.winfo_children():
            w.destroy()
        self.root.update()

    def _update_gui_waiting(self):
        """Show response buttons."""
        if self.root is None:
            return
        self.question_label.config(text=self.gui_config["question"])
        for w in self.button_frame.winfo_children():
            w.destroy()
        for i, label in enumerate(self.gui_config["options"]):
            tk.Button(
                self.button_frame,
                text=label,
                font=("Arial", self.gui_config["font_size"]),
                width=20,
                height=2,
                command=lambda v=i: self._register_response(v)
            ).pack(side=tk.LEFT, padx=10)
        self.root.update()

    def _get_response(self):
        """
        Block until participant clicks a button or presses a key.
        Returns integer response code (0, 1, or 2).
        """
        self._response = None

        def on_key(event):
            for i, key in enumerate(self.gui_config["keys"]):
                if event.char == key:
                    self._register_response(i)
                    return

        self.root.bind("<Key>", on_key)
        self.root.mainloop()         # blocks until _register_response calls quit()
        self.root.unbind("<Key>")
        return self._response

    def _register_response(self, value):
        """Store response and unblock mainloop."""
        self._response = value
        self.root.quit()

    def _close_gui(self):
        """Destroy the GUI window."""
        if self.root is not None:
            self.root.destroy()
            self.root = None

    # ------------------------------------------------------------------ #
    #  Output                                                              #
    # ------------------------------------------------------------------ #

    def _print_summary(self):
        """Print per-frequency LDL results to console."""
        print("\n" + "=" * 50)
        print(f"LDL Summary - {self.participant_id}")
        print("=" * 50)
        for freq in self.frequencies:
            if freq in self.ldl_results:
                amp = self.ldl_results[freq]
                print(f"  {freq:5d} Hz:  {amp:.4f} amplitude  "
                      f"({TrialPlayer.amp2db(amp):.1f} dB rel)")
            else:
                print(f"  {freq:5d} Hz:  no result recorded")
        print("=" * 50)

    def write_data_to_disk(self):
        """
        Save trial-by-trial data to CSV.

        Filename: {participant_id}_LDL_{timestamp}.csv
        Location: test_data/ in current working directory.
        """
        if not self.trial_rows:
            print("No data to save.")
            return None

        timestamp  = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        output_dir = Path.cwd() / "test_data"
        output_dir.mkdir(parents=True, exist_ok=True)
        filename   = output_dir / f"{self.participant_id}_LDL_{timestamp}.csv"

        df = pd.DataFrame(self.trial_rows)
        df.to_csv(filename, index=False)
        print(f"\nData saved to: {filename}")
        return filename
