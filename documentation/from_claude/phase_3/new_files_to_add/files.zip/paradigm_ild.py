"""
Interaural Level Difference (ILD) Paradigm

Adaptive threshold detection for intensity differences between ears.
Measures the smallest level difference between left and right ears that
can be lateralized (heard as coming from one side).

Adaptive parameter: ILD (dB) - level difference between ears
Outer variables: Carrier frequency (fc), reference level
"""

from paradigms.adaptive_paradigm import AdaptiveParadigm
from trial_player import TrialPlayer
from utils.varspec import VarSpec
from psychopy import sound
import random
import numpy as np
import time


class ParadigmILD(AdaptiveParadigm):
    """
    ILD Detection - detect interaural level differences (spatial hearing cue).

    Adaptive behavior:
    - Start with detectable ILD (e.g., 15 dB)
    - Multiplicative steps (halve/double)
    - Track ILD threshold for different frequencies

    Stimulus: Pure tone with amplitude difference between L and R channels.
    Task: "Which side was louder: Left, Right, or Center?"

    ILD is created by scaling channel amplitudes:
    - louder ear  = ref_level * 10^(+ild_dB/40)
    - quieter ear = ref_level * 10^(-ild_dB/40)
    (symmetric split so geometric mean power = ref_level)
    """

    def __init__(self, params: dict[str, VarSpec], verbose=False, gui_config=None, participant_id=None):
        """
        Initialize ILD paradigm.

        Args:
            params: Must include "inner" for ild_dB and "outer_*" for fc, etc.
            verbose: Print debug info
            gui_config: Optional GUI customization (uses good defaults if None)
        """
        if gui_config is None:
            gui_config = {
                'question': "Which SIDE did the sound come from?",
                'options': ['Equal/Center (0)', 'Left (1)', 'Right (2)'],
                'keys': ['0', '1', '2'],
                'window_title': "ILD Test - Interaural Level Difference",
                'font_size': 16
            }

        # CRITICAL: Set paradigm code BEFORE calling super().__init__()
        self.paradigm_code = 'ILD'

        super().__init__(params, verbose=verbose, gui_config=gui_config, participant_id=participant_id)

        # ILD-specific settings
        self.sample_accurate = False
        self.fade_time = 0.05
        self.tone_dur = 0.5

        # Track which side is louder (for response checking)
        self.louder_side = None  # 0=center, 1=left, 2=right

        self.last_two_levels = []

    def initialize_adaptive_param(self):
        """Set initial ILD from inner variable config with randomization."""
        if isinstance(self.inner_var.data, dict):
            base_start = self.inner_var.data.get('start', 15.0)
            randomize_factor = self.inner_var.data.get('randomize_factor', 1.5)
            multiplier = random.uniform(1.0 / randomize_factor, randomize_factor)
            randomized_start = base_start * multiplier
            min_ild = self.inner_var.data.get('min', 0.5)
            max_ild = self.inner_var.data.get('max', 32.0)
            self.ild_dB = max(min_ild, min(max_ild, randomized_start))
        else:
            self.ild_dB = 8.0

        if self.verbose:
            print(f"Initial ILD: {self.ild_dB:.2f} dB")

        self.last_two_levels = []

    def prepare_trial(self):
        """
        Configure trial: tone with ILD between ears.

        For catch trials: equal levels both ears (center).
        For normal trials: one ear is louder by ild_dB.

        ILD is implemented via direct channel amplitude scaling:
            louder ear  = ref_level * 10^(+ild_dB/40)
            quieter ear = ref_level * 10^(-ild_dB/40)
        Symmetric +/-ild_dB/2 split keeps geometric mean power ~ ref_level.

        Bypasses TrialPlayer (same approach as ParadigmITD) to allow
        proper per-channel amplitude control.
        """
        self.trial_num += 1

        ref_level = self.ref_level if hasattr(self, 'ref_level') else 0.3
        fc = self.fc if hasattr(self, 'fc') else 1000.0

        # Generate mono tone
        t = np.arange(0, self.tone_dur, 1.0 / self.fs)
        mono = np.sin(2 * np.pi * fc * t)

        # Apply fade in/out
        fade_samples = int(self.fade_time * self.fs)
        if fade_samples > 0 and 2 * fade_samples <= len(mono):
            fade_window = np.hanning(2 * fade_samples)
            mono[:fade_samples]  *= fade_window[:fade_samples]
            mono[-fade_samples:] *= fade_window[-fade_samples:]

        if self.is_catch_trial:
            amp_left  = ref_level
            amp_right = ref_level
            self.louder_side = 0  # "Equal/Center"
            if self.verbose:
                print(f"  -> Catch trial (center: ILD=0 dB)")
        else:
            # Symmetric +/-ild_dB/2 amplitude split
            half_gain = 10 ** (self.ild_dB / 40.0)
            if random.choice([True, False]):
                amp_left  = ref_level * half_gain
                amp_right = ref_level / half_gain
                self.louder_side = 1  # "Left"
            else:
                amp_left  = ref_level / half_gain
                amp_right = ref_level * half_gain
                self.louder_side = 2  # "Right"

            self.last_two_levels.append(self.ild_dB)
            if len(self.last_two_levels) > 2:
                self.last_two_levels.pop(0)

            if self.verbose:
                side_name = "LEFT" if self.louder_side == 1 else "RIGHT"
                print(f"  -> Normal trial: ILD = {self.ild_dB:.2f} dB, louder = {side_name}")

        left   = amp_left  * mono
        right  = amp_right * mono
        stereo = np.column_stack([left, right])

        self.ild_sound = sound.Sound(
            value=stereo,
            sampleRate=self.fs,
            stereo=True,
            secs=self.tone_dur,
            hamming=False
        )

    def execute_trial(self):
        """Override to play ILD sound directly (bypassing TrialPlayer)."""
        self.trial_repeats += 1
        if self.verbose:
            print(f"Playing ILD sound (trial repeat {self.trial_repeats})...")
        self.ild_sound.play()
        time.sleep(self.tone_dur + 0.1)

    def check_answer(self):
        """
        Override to handle 3-response format (left/center/right).

        Response classification:
        - Normal trial: answer matches louder_side -> TP
        - Normal trial: wrong side -> FN
        - Catch trial: answer = center -> TN
        - Catch trial: answer = left or right -> FP
        """
        if self.user_input == "repeat":
            return

        response = int(self.user_input)  # 0, 1, or 2

        if self.is_catch_trial:
            if response == 0:
                self.correct_answer = 'TN'
            else:
                self.correct_answer = 'FP'
        else:
            if response == self.louder_side:
                self.correct_answer = 'TP'
            else:
                self.correct_answer = 'FN'

        if self.verbose:
            side_names = ['Equal/Center', 'Left', 'Right']
            print(f"User: {side_names[response]}, Correct: {side_names[self.louder_side]}, Class: {self.correct_answer}")

    def adapt_difficulty(self, direction):
        """Adjust ILD using multiplicative steps (same pattern as DLI)."""
        if isinstance(self.inner_var.data, dict):
            if self.total_num_reversals == 0:
                step_down_factor = self.inner_var.data.get('step_down_initial', 0.5)
                step_up_factor   = self.inner_var.data.get('step_up_initial',   2.0)
            else:
                step_down_factor = self.inner_var.data.get('step_down_final', 0.5)
                step_up_factor   = self.inner_var.data.get('step_up_final',   2.0)
            min_ild = self.inner_var.data.get('min', 0.5)
            max_ild = self.inner_var.data.get('max', 32.0)
        else:
            step_down_factor = 0.5
            step_up_factor   = 2.0
            min_ild = 0.5
            max_ild = 32.0

        if direction == "harder":
            self.ild_dB = max(self.ild_dB * step_down_factor, min_ild)
            if self.verbose:
                print(f"  -> Harder: {self.ild_dB:.2f} dB")
        elif direction == "easier":
            self.ild_dB = min(self.ild_dB * step_up_factor, max_ild)
            if self.verbose:
                print(f"  -> Easier: {self.ild_dB:.2f} dB")

    def reset_to_midpoint_ild(self):
        """Reset ILD to geometric mean of last two levels."""
        if len(self.last_two_levels) == 2:
            midpoint = np.sqrt(self.last_two_levels[0] * self.last_two_levels[1])
            self.ild_dB = midpoint
            if self.verbose:
                print(f"  -> Reset to midpoint: {midpoint:.2f} dB")

    def update_trial_params(self):
        """Override to handle midpoint reset."""
        if self.reset_to_midpoint:
            self.reset_to_midpoint_ild()
            self.reset_to_midpoint = False
            self.make_harder = False
            self.make_easier = False
        super().update_trial_params()

    def get_log_data(self):
        """Return ILD-specific data for CSV logging."""
        log_dict = {
            "ild_dB":      self.ild_dB,
            "louder_side": self.louder_side,  # 0=center, 1=left, 2=right
        }
        if hasattr(self, 'fc'):
            log_dict["fc"] = self.fc
        if hasattr(self, 'ref_level'):
            log_dict["ref_level"] = self.ref_level
        return log_dict

    def get_trial_description(self):
        """Return description for GUI display."""
        fc_desc = f"{self.fc:.0f} Hz" if hasattr(self, 'fc') else "ILD"
        return f"Config {self.config_num}/{self.total_num_configs} ({fc_desc}), Trial {self.trial_num}"


# Example usage
if __name__ == "__main__":
    print("=" * 60)
    print("ILD Detection Paradigm Test")
    print("=" * 60)

    params = {
        "inner": VarSpec(
            name="ild_dB",
            data={
                'start': 8.0,
                'step_down_initial': 0.5,
                'step_down_final':   0.5,
                'step_up_initial':   2.0,
                'step_up_final':     2.0,
                'min': 0.5,
                'max': 32.0,
                'randomize_factor': 1.5
            }
        ),
        "outer_1": VarSpec(name="fc",        data=[1000, 2000]),
        "outer_2": VarSpec(name="ref_level", data=[0.3]),
    }

    ild = ParadigmILD(params, verbose=True)

    print(f"\nStarting ILD paradigm...")
    print(f"Testing {ild.total_num_configs} configurations")
    print("\nPress Ctrl+C to abort\n")

    try:
        ild.main()
    except KeyboardInterrupt:
        print("\n\nTest aborted")
