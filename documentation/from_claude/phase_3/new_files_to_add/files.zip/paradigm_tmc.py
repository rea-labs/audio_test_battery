"""
TMC (Temporal Masking Curve) Paradigm

Measures auditory compression using forward masking.

A fixed-level probe tone follows a masker tone at the same frequency.
The masker level is adaptively varied to find the masked threshold of the probe.
This is repeated across different masker-probe gaps. The resulting curve (masker
threshold vs. gap duration) has a slope that reflects cochlear compression:
steeper slope = more compression = healthier cochlea.

Adaptive parameter: Masker level (dB SPL)
  - Probe heard  -> masker too weak  -> INCREASE masker (harder)
  - Probe masked -> masker too strong -> DECREASE masker (easier)

Outer variables: gap_duration, probe_freq, probe_level
  - gap_duration: fixed per run, varied across runs (e.g. [0.030, 0.050, 0.070] s)
  - probe_freq:   target frequency (Hz)
  - probe_level:  fixed probe amplitude (from PTA threshold + 10 dB SL)

Key differences from IFMC:
  - Gap is the outer variable (not masker frequency ratio)
  - Masker frequency = probe frequency (on-frequency masker, ratio = 1.0)
  - Masker duration: 108 ms (same as IFMC)
  - Probe duration:  16 ms  (same as IFMC)

Based on:
  - Lecluyse & Meddis (2013) Int J Audiol
  - MultiThreshold toolbox (Essex/Zurich)
  - PROLACTIN paradigm plan (gaps: 30, 50, 70 ms; frequencies: 500, 1000 Hz)
"""

from paradigms.adaptive_paradigm import AdaptiveParadigm
from trial_player import TrialPlayer
from utils.varspec import VarSpec
import random
import numpy as np


class ParadigmTMC(AdaptiveParadigm):
    """
    TMC - measure auditory compression via forward masking.

    Stimulus structure per trial:
      [Masker 108 ms] -> [Gap N ms] -> [Probe 16 ms]

    Masker and probe have the SAME frequency (on-frequency masking).
    Gap is fixed within a run; masker level is adapted trial-by-trial.

    Task: "Did you hear the short tone (probe) after the louder tone?"
    Response: 1 = yes (heard probe), 0 = no (probe was masked)

    Expected output:
      Normal hearing:   steep TMC slope (~30-40 dB / 100 ms)
      Hearing impaired: shallow slope (compression reduced/absent)
    """

    def __init__(self, params, verbose=False, gui_config=None, participant_id=None):
        """
        Args:
            params: Must include:
                "inner"   : masker_level (dB SPL) - adaptive parameter
                "outer_1" : gap_duration (s)       - varied across runs
                "outer_2" : probe_freq (Hz)        - test frequency
                "outer_3" : probe_level (amplitude 0-1) - from PTA + 10 dB SL
            verbose: Print debug output
            gui_config: Optional GUI customization dict
            participant_id: Participant identifier string
        """
        if gui_config is None:
            gui_config = {
                "question": "Did you hear the short tone at the end?",
                "options": ["No (0)", "Yes (1)"],
                "keys": ["0", "1"],
                "window_title": "TMC Test - Temporal Masking",
                "font_size": 14
            }

        # CRITICAL: must be set BEFORE super().__init__()
        self.paradigm_code = "TMC"

        super().__init__(params, verbose=verbose, gui_config=gui_config,
                         participant_id=participant_id)

        # Timing constants (Lecluyse 2013)
        self.masker_dur = 0.108   # 108 ms masker
        self.probe_dur  = 0.016   # 16 ms probe
        self.ramp_dur   = 0.004   # 4 ms raised-cosine ramps

        # gap_duration is read per-config from outer_1 (in seconds)
        # probe_freq    is read per-config from outer_2 (in Hz)
        # probe_level   is read per-config from outer_3 (amplitude 0-1)

    # ------------------------------------------------------------------
    # Adaptive parameter initialisation
    # ------------------------------------------------------------------

    def initialize_adaptive_param(self):
        """
        Set initial masker level.

        Start LOW so the probe is clearly audible on the first trials,
        helping the participant understand the task.
        Randomise slightly around the start value (MultiThreshold protocol).
        """
        if isinstance(self.inner_var.data, dict):
            base_start = self.inner_var.data.get("start", 10.0)

            # Small randomisation: +/- half the large step size
            step_initial = abs(self.inner_var.data.get("step_up_initial", 10))
            half_step    = step_initial / 2.0
            offset       = random.uniform(-half_step, half_step)

            start_level  = base_start + offset
            min_level    = self.inner_var.data.get("min", 0)
            max_level    = self.inner_var.data.get("max", 100)
            self.masker_level = max(min_level, min(max_level, start_level))
        else:
            self.masker_level = 10.0

        if self.verbose:
            print(f"  Initial masker level: {self.masker_level:.1f} dB SPL  "
                  f"(gap = {self.gap_duration * 1000:.0f} ms, "
                  f"probe = {self.probe_freq:.0f} Hz)")

    # ------------------------------------------------------------------
    # Trial generation
    # ------------------------------------------------------------------

    def prepare_trial(self):
        """
        Build the audio for one trial.

        Normal trial:  [masker 108 ms] -> [gap N ms] -> [probe 16 ms]
        Catch trial:   [masker 108 ms] -> [gap N ms]  (no probe)

        Masker and probe share the same frequency (on-frequency masking).
        """
        self.trial_num += 1

        masker_amp = self._db_to_amp(self.masker_level)
        probe_amp  = self.probe_level         # amplitude from outer_3
        freq       = self.probe_freq          # masker = probe frequency
        gap        = self.gap_duration        # seconds, from outer_1

        if self.is_catch_trial:
            if self.verbose:
                print(f"  -> Catch trial (no probe, gap={gap*1000:.0f} ms)")

            self.tp.new_trial(
                wave_type="sin",
                durations=self.masker_dur,
                fc=freq,
                amp=masker_amp,
                fade_time=self.ramp_dur,
                verbose=False
            )

        else:
            if self.verbose:
                print(f"  -> Normal trial: masker={self.masker_level:.1f} dB, "
                      f"gap={gap*1000:.0f} ms, freq={freq:.0f} Hz, "
                      f"probe amp={probe_amp:.4f}")

            self.tp.new_trial(
                wave_type=["sin", "sin"],
                durations=[self.masker_dur, self.probe_dur],
                del_times=gap,
                fc=[freq, freq],
                amp=[masker_amp, probe_amp],
                fade_time=self.ramp_dur,
                verbose=False
            )

    # ------------------------------------------------------------------
    # Response classification  (identical logic to IFMC)
    # ------------------------------------------------------------------

    def check_answer(self):
        """
        Classify response for catch vs. normal trials.

        Catch trial (probe absent):
          0 -> TN  (correct rejection)
          1 -> FP  (false alarm)

        Normal trial (probe present):
          1 -> TP  (probe detected)
          0 -> FN  (probe masked)
        """
        if self.user_input == "repeat":
            return

        response = int(self.user_input)

        if self.is_catch_trial:
            self.correct_answer = "TN" if response == 0 else "FP"
        else:
            self.correct_answer = "TP" if response == 1 else "FN"

        if self.verbose:
            label = "Yes" if response == 1 else "No"
            print(f"  User: {label} -> {self.correct_answer}")

    # ------------------------------------------------------------------
    # Adaptive difficulty update  (identical logic to IFMC)
    # ------------------------------------------------------------------

    def update_streaks_and_difficulty(self):
        """
        REVERSED adaptive logic (same as IFMC):
          TP -> probe heard  -> masker too weak  -> make HARDER
          FN -> probe masked -> masker too strong -> make EASIER
          Catch trials do not affect adaptive tracking.
        """
        if self.is_catch_trial:
            return

        if self.correct_answer == "TP":
            self.current_streak += 1
            if self.current_streak >= self.target_streak_correct:
                self.make_harder = True
                self.current_streak = 0
                if self.verbose:
                    print(f"  *** {self.target_streak_correct} correct -> HARDER")

        elif self.correct_answer == "FN":
            self.current_streak = 0
            self.make_easier = True
            if self.verbose:
                print("  *** Probe masked -> EASIER")

    def adapt_difficulty(self, direction):
        """
        Adjust masker level.

        REVERSED logic:
          harder -> increase masker level
          easier -> decrease masker level
        """
        if isinstance(self.inner_var.data, dict):
            if self.total_num_reversals == 0:
                step_up   = self.inner_var.data.get("step_up_initial",   10)
                step_down = self.inner_var.data.get("step_down_initial", -10)
            else:
                step_up   = self.inner_var.data.get("step_up_final",   2)
                step_down = self.inner_var.data.get("step_down_final", -2)
            min_level = self.inner_var.data.get("min",   0)
            max_level = self.inner_var.data.get("max", 100)
        else:
            step_up   =  10 if self.total_num_reversals == 0 else  2
            step_down = -10 if self.total_num_reversals == 0 else -2
            min_level, max_level = 0, 100

        if direction == "harder":
            self.masker_level = min(self.masker_level + step_up,   max_level)
            if self.verbose:
                print(f"  -> Harder: masker = {self.masker_level:.1f} dB")
        elif direction == "easier":
            self.masker_level = max(self.masker_level + step_down, min_level)
            if self.verbose:
                print(f"  -> Easier: masker = {self.masker_level:.1f} dB")

    # ------------------------------------------------------------------
    # Logging
    # ------------------------------------------------------------------

    def get_log_data(self):
        """Return TMC-specific columns for CSV."""
        return {
            "masker_level": self.masker_level,
            "gap_duration": self.gap_duration,
            "probe_freq":   self.probe_freq,
            "probe_level":  self.probe_level,
        }

    def get_trial_description(self):
        """Short description shown in operator display."""
        return (f"Config {self.config_num}/{self.total_num_configs} "
                f"(probe={self.probe_freq:.0f} Hz, "
                f"gap={self.gap_duration*1000:.0f} ms), "
                f"Trial {self.trial_num}")

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _db_to_amp(self, db_spl):
        """
        Convert dB SPL to amplitude (0-1).

        Uses the same simple linear mapping as IFMC:
            0 dB SPL  -> 0.0 amplitude
            100 dB SPL -> 1.0 amplitude

        TODO: replace with proper calibrated mapping.
        """
        db_spl = max(0, min(100, db_spl))
        return db_spl / 100.0
