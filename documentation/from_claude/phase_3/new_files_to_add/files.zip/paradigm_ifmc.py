"""
IFMC (Iso-Forward Masking Contour) Paradigm

Measures frequency selectivity (cochlear tuning) using forward masking.
Tracks how much a masker tone at different frequencies is needed to mask 
a fixed-level, fixed-frequency probe tone.

Adaptive parameter: Masker level (dB SPL)
Outer variables: Masker frequency ratio (fm/fp), probe frequency

Based on:
- Lecluyse & Meddis (2013) - Int J Audiol
- MultiThreshold toolbox (Essex/Zurich)
"""

from paradigms.adaptive_paradigm import AdaptiveParadigm
from trial_player import TrialPlayer
from utils.varspec import VarSpec
import random
import numpy as np


class ParadigmIFMC(AdaptiveParadigm):
    """
    IFMC - measure frequency selectivity via forward masking.
    
    Stimulus sequence:
    [Masker tone 108ms] Ã¢â€ â€™ [Gap 10ms] Ã¢â€ â€™ [Probe tone 16ms]
    
    Adaptive parameter: Masker level (dB SPL)
    - Probe heard Ã¢â€ â€™ masker too weak Ã¢â€ â€™ INCREASE masker level
    - Probe not heard Ã¢â€ â€™ masker masks it Ã¢â€ â€™ DECREASE masker level
    
    Task: "Did you hear the probe tone (the short click at the end)?"
    
    Expected results:
    - Normal hearing: V-shaped contour (sharp frequency selectivity)
    - Hearing loss: Broad/flat contour (poor frequency selectivity)
    """
    
    def __init__(self, params: dict[str, VarSpec], verbose=False, gui_config=None, participant_id=None):
        """
        Initialize IFMC paradigm.
        
        Args:
            params: Must include:
                - "inner": masker_level (dB SPL)
                - "outer_1": masker_freq_ratio (fm/fp ratios)
                - "outer_2": probe_freq (Hz)
                - "outer_3": probe_level (amplitude 0-1, NOT dB)
            verbose: Print debug info
            gui_config: Optional GUI customization
        """
        if gui_config is None:
            gui_config = {
                'question': "Did you hear the PROBE tone (short click at the end)?",
                'options': ['No (0)', 'Yes (1)'],
                'keys': ['0', '1'],
                'window_title': "IFMC Test - Frequency Selectivity",
                'font_size': 14
            }
        
        # CRITICAL: Set paradigm code BEFORE calling super().__init__()
        self.paradigm_code = 'IFMC'

        super().__init__(params, verbose=verbose, gui_config=gui_config, participant_id=participant_id)
        
        # IFMC-specific timing (from Lecluyse 2013)
        self.masker_dur = 0.108   # 108 ms
        self.gap_dur = 0.010      # 10 ms gap
        self.probe_dur = 0.016    # 16 ms (short probe)
        self.ramp_dur = 0.004     # 4 ms raised-cosine ramps
        
        # Not sample-accurate (normal timing is fine)
        self.sample_accurate = False
    
    def initialize_adaptive_param(self):
        """Set initial masker level from inner variable config."""
        if isinstance(self.inner_var.data, dict):
            base_start = self.inner_var.data.get('start', 20.0)  # Start low
            
            # Could randomize start level slightly
            randomize_factor = self.inner_var.data.get('randomize_factor', 1.2)
            multiplier = random.uniform(1.0/randomize_factor, randomize_factor)
            randomized_start = base_start * multiplier
            
            min_level = self.inner_var.data.get('min', 0)
            max_level = self.inner_var.data.get('max', 100)
            self.masker_level = max(min_level, min(max_level, randomized_start))
            
            if self.verbose:
                print(f"Initial masker level: {self.masker_level:.1f} dB SPL")
        else:
            self.masker_level = 20.0
            if self.verbose:
                print(f"Initial masker level: {self.masker_level:.1f} dB SPL")
    
    def prepare_trial(self):
        """
        Configure trial: masker tone Ã¢â€ â€™ gap Ã¢â€ â€™ probe tone.
        
        For catch trials (20%): No probe tone (masker + gap only)
        For normal trials: Masker + gap + probe
        
        Task: "Did you hear the probe?"
        """
        self.trial_num += 1
        
        # Calculate actual masker frequency from ratio
        masker_freq = self.probe_freq * self.masker_freq_ratio
        
        # Convert masker level (dB SPL scale) to amplitude
        masker_amp = self.db_spl_to_amplitude(self.masker_level)
        
        # Probe level is directly specified as amplitude (0-1)
        probe_amp = self.probe_level
        
        if self.is_catch_trial:
            # Catch trial: masker + gap, NO probe
            # User should respond "No" (did not hear probe)
            
            if self.verbose:
                print(f"  -> Catch trial (no probe)")
            
            # Just masker, no probe
            self.tp.new_trial(
                wave_type="sin",
                durations=self.masker_dur,
                fc=masker_freq,
                amp=masker_amp,
                fade_time=self.ramp_dur,
                verbose=False
            )
            
        else:
            # Normal trial: masker + gap + probe
            
            if self.verbose:
                print(f"  -> Normal trial: masker={self.masker_level:.1f} dB at {masker_freq:.0f} Hz, probe at {self.probe_freq:.0f} Hz")
            
            # Masker followed by probe with gap between
            self.tp.new_trial(
                wave_type=["sin", "sin"],
                durations=[self.masker_dur, self.probe_dur],
                del_times=self.gap_dur,  # Gap between masker and probe
                fc=[masker_freq, self.probe_freq],
                amp=[masker_amp, probe_amp],
                fade_time=self.ramp_dur,
                verbose=False
            )
    
    def db_spl_to_amplitude(self, db_spl):
        """
        Convert dB SPL to amplitude (0-1 scale).
        
        Simple linear mapping for now:
        0 dB SPL Ã¢â€ â€™ 0 amplitude
        100 dB SPL Ã¢â€ â€™ 1.0 amplitude
        
        TODO: Proper psychophysical calibration
        """
        # Clamp to reasonable range
        db_spl = max(0, min(100, db_spl))
        
        # Linear mapping (simple approximation)
        amplitude = db_spl / 100.0
        
        return amplitude
    
    def check_answer(self):
        """
        Check response for catch vs normal trials.
        
        Catch trial (no probe):
          - Response "No" (0) Ã¢â€ â€™ TN (correct - didn't hear non-existent probe)
          - Response "Yes" (1) Ã¢â€ â€™ FP (false alarm - claimed to hear absent probe)
        
        Normal trial (probe present):
          - Response "Yes" (1) Ã¢â€ â€™ TP (heard probe)
          - Response "No" (0) Ã¢â€ â€™ FN (missed probe)
        
        NOTE: We don't know "correct" answer for normal trials a priori
        because we're adaptively finding the masker threshold.
        Use TP/FN to track probe detection.
        """
        if self.user_input == "repeat":
            return
        
        response = int(self.user_input)  # 0 or 1
        
        if self.is_catch_trial:
            # Catch trial: probe absent
            if response == 0:  # Said "No"
                self.correct_answer = 'TN'  # Correct - no probe present
            else:  # Said "Yes"
                self.correct_answer = 'FP'  # False alarm
        else:
            # Normal trial: probe present
            # We're trying to find masker threshold, so we track detection
            if response == 1:  # Heard probe
                self.correct_answer = 'TP'  # Detected probe
            else:  # Didn't hear probe
                self.correct_answer = 'FN'  # Probe was masked
        
        if self.verbose:
            print(f"User: {'Yes' if response == 1 else 'No'}, Classification: {self.correct_answer}")
    
    def adapt_difficulty(self, direction):
        """
        Adjust masker level to find masking threshold.
        
        REVERSED LOGIC (compared to typical threshold):
        - Harder = INCREASE masker level (makes probe harder to hear)
        - Easier = DECREASE masker level (makes probe easier to hear)
        
        Uses LINEAR steps in dB (not multiplicative).
        """
        if isinstance(self.inner_var.data, dict):
            if self.total_num_reversals == 0:
                step_down = self.inner_var.data.get('step_down_initial', -10)  # Decrease masker
                step_up = self.inner_var.data.get('step_up_initial', 10)       # Increase masker
            else:
                step_down = self.inner_var.data.get('step_down_final', -2)     # Finer steps
                step_up = self.inner_var.data.get('step_up_final', 2)
            
            min_level = self.inner_var.data.get('min', 0)
            max_level = self.inner_var.data.get('max', 100)
        else:
            step_down = -10 if self.total_num_reversals == 0 else -2
            step_up = 10 if self.total_num_reversals == 0 else 2
            min_level = 0
            max_level = 100
        
        if direction == "harder":
            # Probe was heard Ã¢â€ â€™ masker too weak Ã¢â€ â€™ INCREASE masker
            self.masker_level += step_up
            self.masker_level = min(self.masker_level, max_level)
            if self.verbose:
                print(f"  -> Harder: masker = {self.masker_level:.1f} dB (increased)")
        
        elif direction == "easier":
            # Probe was masked Ã¢â€ â€™ masker too strong Ã¢â€ â€™ DECREASE masker
            self.masker_level += step_down  # Note: step_down is negative
            self.masker_level = max(self.masker_level, min_level)
            if self.verbose:
                print(f"  -> Easier: masker = {self.masker_level:.1f} dB (decreased)")
    
    def update_streaks_and_difficulty(self):
        """
        Override to handle REVERSED adaptive logic.
        
        In IFMC:
        - Probe detected (TP) Ã¢â€ â€™ masker too weak Ã¢â€ â€™ make HARDER (increase masker)
        - Probe masked (FN) Ã¢â€ â€™ masker too strong Ã¢â€ â€™ make EASIER (decrease masker)
        - False alarm (FP) Ã¢â€ â€™ bad, but doesn't affect masker level
        - True negative (TN) Ã¢â€ â€™ good, doesn't affect masker level
        """
        # Handle catch trials
        if self.is_catch_trial:
            # TN or FP doesn't affect adaptive tracking
            # Just monitor false alarm rate
            return
        
        # Handle normal trials (adaptive tracking)
        if self.correct_answer == 'TP':
            # Probe detected Ã¢â€ â€™ masker insufficient Ã¢â€ â€™ need to INCREASE masker
            self.current_streak += 1
            
            if self.current_streak >= self.target_streak_correct:
                self.make_harder = True
                self.current_streak = 0
                
                if self.verbose:
                    print(f"*** {self.target_streak_correct} correct in a row Ã¢â€ â€™ making HARDER")
        
        elif self.correct_answer == 'FN':
            # Probe masked Ã¢â€ â€™ masker too strong Ã¢â€ â€™ need to DECREASE masker
            self.current_streak = 0
            self.make_easier = True
            
            if self.verbose:
                print(f"*** Probe masked Ã¢â€ â€™ making EASIER")
    
    def get_log_data(self):
        """Return IFMC-specific data for CSV logging."""
        log_dict = {
            "masker_level": self.masker_level,
            "masker_freq": self.probe_freq * self.masker_freq_ratio,
            "masker_freq_ratio": self.masker_freq_ratio,
            "probe_freq": self.probe_freq,
            "probe_level": self.probe_level
        }
        
        return log_dict
    
    def get_trial_description(self):
        """Return description for GUI display."""
        return f"Config {self.config_num}/{self.total_num_configs} (probe={self.probe_freq:.0f} Hz, ratio={self.masker_freq_ratio:.1f}), Trial {self.trial_num}"


# Example usage
if __name__ == "__main__":
    print("=" * 60)
    print("IFMC Paradigm Test")
    print("=" * 60)
    
    # Configuration based on Lecluyse 2013
    params = {
        "inner": VarSpec(
            name="masker_level",
            data={
                'start': 20.0,           # Start masker low
                'step_down_initial': -10, # Decrease masker by 10 dB
                'step_down_final': -2,    # Then by 2 dB after reversal
                'step_up_initial': 10,    # Increase masker by 10 dB
                'step_up_final': 2,       # Then by 2 dB after reversal
                'min': 0,                 # Cannot go below 0 dB SPL
                'max': 100,               # Reasonable maximum
                'randomize_factor': 1.2
            }
        ),
        "outer_1": VarSpec(
            name="masker_freq_ratio",
            data=[0.5, 0.7, 0.9, 1.0, 1.1, 1.3, 1.6],  # fm/fp ratios
            # Random order handled by shuffling configs
        ),
        "outer_2": VarSpec(
            name="probe_freq",
            data=[1000]  # Test at 1 kHz
        ),
        "outer_3": VarSpec(
            name="probe_level",
            data=[50]  # User-specified: 10 dB above threshold
        )
    }
    
    ifmc = ParadigmIFMC(params, verbose=True)
    
    print("\nStarting IFMC paradigm...")
    print(f"Testing {ifmc.total_num_configs} configurations")
    print("\nPress Ctrl+C to abort\n")
    
    try:
        ifmc.main()
    except KeyboardInterrupt:
        print("\n\nTest aborted")
