"""
Pure Tone Audiogram (PTA) Paradigm

Adaptive threshold detection for pure tones at different frequencies.
Measures the quietest tone a participant can detect.

Adaptive parameter: Amplitude (dB SPL)
Outer variables: Frequency (Hz), Duration (sec)
"""

from paradigms.adaptive_paradigm import AdaptiveParadigm
from trial_player import TrialPlayer
from utils.varspec import VarSpec
import random


class ParadigmPTA(AdaptiveParadigm):
    """
    Pure Tone Audiogram - detect tones at threshold across frequencies.
    
    Adaptive behavior:
    - Start at comfortable level with randomization (per MultiThreshold protocol)
    - Large steps (+/- 10 dB) before first reversal
    - Small steps (Ãƒâ€šÃ‚Â±2 dB) after first reversal  
    - Midpoint reset after first reversal (using last two presented levels)
    - Track threshold for each frequency
    """
    
    def __init__(self, params: dict[str, VarSpec], verbose=False, gui_config=None, participant_id=None):
        """
        Initialize PTA paradigm.
        
        Args:
            params: Must include "inner" for amplitude and "outer_*" for frequencies/durations
            verbose: Print debug info
            gui_config: Optional GUI customization (uses good defaults if None)
            participant_id: Participant ID for data file naming
        """
        # CRITICAL: Set paradigm code BEFORE calling super().__init__()
        self.paradigm_code = 'PTA'
        
        # Set up GUI config if not provided
        if gui_config is None:
            gui_config = {
                'question': "Did you hear a tone?",
                'options': ['No (0)', 'Yes (1)'],
                'keys': ['0', '1'],
                'window_title': "Pure Tone Audiogram",
                'font_size': 16
            }
        
        # Call parent constructor
        super().__init__(params, verbose=verbose, gui_config=gui_config, participant_id=participant_id)
        
        # Default for optional outer variable (overridden if trial_dur is in params)
        if not hasattr(self, 'trial_dur'):
            self.trial_dur = 0.5         # Default tone duration (sec)

        # Track last two presented levels for midpoint calculation
        # (per Lecluyse & Meddis 2009: midpoint between last two levels)
        self.last_two_levels = []
    
    def initialize_adaptive_param(self):
        """
        Set initial amplitude from inner variable config with randomization.
        
        Per MultiThreshold protocol:
        - Start level is randomized +/- half of initial step size
        - This ensures supra-threshold start and prevents edge cases
        """
        if isinstance(self.inner_var.data, dict):
            base_start = self.inner_var.data.get('start', 1.0)
            
            # Get initial step size to derive randomization range
            # Per MultiThreshold: randomize within +/- half of large step size
            step_down_initial = abs(self.inner_var.data.get('step_down_initial', -10))
            randomize_dB = step_down_initial / 2.0  # Half of initial step
            
            # Add random offset in dB space
            base_start_dB = TrialPlayer.amp2db(base_start)
            offset_dB = random.uniform(-randomize_dB, randomize_dB)
            randomized_start_dB = base_start_dB + offset_dB
            
            # Convert back to amplitude and clip to valid range
            self.trial_amp = TrialPlayer.db2amp(randomized_start_dB)
            min_amp = self.inner_var.data.get('min', 0.001)
            max_amp = self.inner_var.data.get('max', 1.0)
            self.trial_amp = max(min_amp, min(max_amp, self.trial_amp))
            
            if self.verbose:
                print(f"Initial amplitude: {self.trial_amp:.4f} ({TrialPlayer.amp2db(self.trial_amp):.1f} dB)")
                print(f"  (base: {base_start_dB:.1f} dB, offset: {offset_dB:+.1f} dB, range: +/-{randomize_dB:.1f} dB)")
        else:
            self.trial_amp = 1.0
            if self.verbose:
                print(f"Initial amplitude: {self.trial_amp} ({TrialPlayer.amp2db(self.trial_amp):.1f} dB)")
        
        # Reset tracking
        self.last_two_levels = []

    def prepare_trial(self):
        """
        Configure trial: pure tone at current frequency and adaptive amplitude.
        
        For catch trials, amplitude = 0 (silence).
        For normal trials, amplitude = current adaptive level.
        """
        self.trial_num += 1
        
        # Determine amplitude based on catch trial status
        if self.is_catch_trial:
            amp = 0.0  # Silence for catch trial
            if self.verbose:
                print(f"  -> Catch trial (silence)")
        else:
            amp = self.trial_amp
            # Track this presented level for midpoint calculation
            self.last_two_levels.append(self.trial_amp)
            if len(self.last_two_levels) > 2:
                self.last_two_levels.pop(0)  # Keep only last 2
            
            if self.verbose:
                print(f"  -> Normal trial: {self.fc:.0f} Hz @ {TrialPlayer.amp2db(amp):.1f} dB")
        
        # Configure trial using TrialPlayer
        self.tp.new_trial(
            wave_type="sin",
            durations=self.trial_dur,
            fc=self.fc,
            amp=amp,
            fade_time=self.fade_time,
            sample_accurate=self.sample_accurate,
            pan=self.pan,
            verbose=False
        )
    
    def adapt_difficulty(self, direction):
        """
        Adjust amplitude to make detection harder or easier.
        
        Harder: Decrease amplitude (quieter tone)
        Easier: Increase amplitude (louder tone)
        
        Uses different step sizes before/after first reversal per MultiThreshold protocol.
        """
        # Get step sizes from config or use defaults
        if isinstance(self.inner_var.data, dict):
            # Before first reversal - use initial (large) step sizes
            if self.total_num_reversals == 0:
                step_down = self.inner_var.data.get('step_down_initial', -10)  # dB
                step_up = self.inner_var.data.get('step_up_initial', 10)       # dB
            # After first reversal - use final (small) step sizes
            else:
                step_down = self.inner_var.data.get('step_down_final', -2)     # dB
                step_up = self.inner_var.data.get('step_up_final', 2)          # dB
            
            min_amp = self.inner_var.data.get('min', 0.001)
            max_amp = self.inner_var.data.get('max', 1.0)
        else:
            # Fallback defaults
            step_down = -10 if self.total_num_reversals == 0 else -2
            step_up = 10 if self.total_num_reversals == 0 else 2
            min_amp = 0.001
            max_amp = 1.0
        
        # Adjust amplitude
        if direction == "harder":
            self.trial_amp *= TrialPlayer.db2amp(step_down)  # Quieter
            self.trial_amp = max(self.trial_amp, min_amp)    # Floor
            if self.verbose:
                print(f"  -> Harder: {TrialPlayer.amp2db(self.trial_amp):.1f} dB (step: {step_down} dB)")
        
        elif direction == "easier":
            self.trial_amp *= TrialPlayer.db2amp(step_up)    # Louder
            self.trial_amp = min(self.trial_amp, max_amp)    # Ceiling
            if self.verbose:
                print(f"  -> Easier: {TrialPlayer.amp2db(self.trial_amp):.1f} dB (step: {step_up} dB)")
    
    def reset_to_midpoint_amplitude(self):
        """
        Reset amplitude to midpoint between last two presented levels.
        Called after first reversal as per MultiThreshold protocol.
        
        Per Lecluyse & Meddis (2009): "the stimulus level is set to the 
        mid-point between the two previous levels"
        """
        if len(self.last_two_levels) == 2:
            # Calculate midpoint in dB space
            level1_dB = TrialPlayer.amp2db(self.last_two_levels[0])
            level2_dB = TrialPlayer.amp2db(self.last_two_levels[1])
            midpoint_dB = (level1_dB + level2_dB) / 2.0
            
            # Convert back to amplitude
            self.trial_amp = TrialPlayer.db2amp(midpoint_dB)
            
            if self.verbose:
                print(f"  -> Reset to midpoint: {midpoint_dB:.1f} dB")
                print(f"     (between last two levels: {level1_dB:.1f} dB and {level2_dB:.1f} dB)")
        else:
            if self.verbose:
                print(f"  -> Warning: Cannot reset to midpoint (need 2 levels, have {len(self.last_two_levels)})")
    
    def update_trial_params(self):
        """
        Override to handle midpoint reset after first reversal.
        """
        # Handle midpoint reset if flagged
        if self.reset_to_midpoint:
            self.reset_to_midpoint_amplitude()
            self.reset_to_midpoint = False
            
            # Clear difficulty adjustment flags since we just reset to midpoint
            # This prevents double adjustment (midpoint + step)
            self.make_harder = False
            self.make_easier = False
        
        # Call parent implementation for normal difficulty adjustment
        super().update_trial_params()
    
    def get_log_data(self):
        """
        Return PTA-specific data for CSV logging.
        
        Returns column names matching the actual parameter names from VarSpec:
        - trial_amp: Adaptive amplitude parameter (inner variable)
        - fc: Frequency in Hz (outer variable 1)
        - trial_dur: Duration in seconds (outer variable 2)
        
        Note: Values are in their natural units (amplitude in dB, frequency in Hz, etc.)
        """
        return {
            "trial_amp": TrialPlayer.amp2db(self.trial_amp),  # Inner variable (adaptive param)
            "fc": self.fc,                                     # Outer variable 1
            "trial_dur": self.trial_dur                        # Outer variable 2
        }
    
    def get_trial_description(self):
        """
        Return description for GUI display.
        
        Returns:
            String like "Config 2/5 (1000 Hz), Trial 8"
        """
        return f"Config {self.config_num}/{self.total_num_configs} ({self.fc:.0f} Hz), Trial {self.trial_num}"


# Example usage and testing
if __name__ == "__main__":
    print("=" * 60)
    print("PTA Paradigm Test")
    print("=" * 60)
    
    # Define parameters with initial/final step sizes
    params = {
        "inner": VarSpec(
            name="trial_amp",
            data={
                'start': 0.5,                # Start at 50% amplitude --> reduce this!
                'randomize_start': 5,        # Ãƒâ€šÃ‚Â±5 dB randomization
                'step_down_initial': -10,    # Large step before first reversal
                'step_down_final': -2,       # Small step after first reversal
                'step_up_initial': 10,       # Large step before first reversal
                'step_up_final': 2,          # Small step after first reversal
                'min': 0.001,                # Minimum amplitude (~ -60 dB)
                'max': 1.0                   # Maximum amplitude (0 dB)
            }
        ),
        "outer_1": VarSpec(
            name="fc",
            data=[500, 1000, 2000, 4000]  # Test frequencies
        ),
        "outer_2": VarSpec(
            name="trial_dur",
            data=[0.5, 1.0]  # Test durations
        )
    }
    
    # Create and run paradigm
    pta = ParadigmPTA(params, verbose=True)
    
    print("\nStarting PTA paradigm...")
    print(f"Testing {pta.total_num_configs} configurations")
    print(f"Frequencies: {[v.data for v in pta.outer_vars if v.name == 'fc'][0]}")
    print("\nPress Ctrl+C to abort\n")
    
    try:
        pta.main()
    except KeyboardInterrupt:
        print("\n\nTest aborted by user")
        if len(pta.data) > 0:
            print("\nPartial results:")
            print(pta.data)
