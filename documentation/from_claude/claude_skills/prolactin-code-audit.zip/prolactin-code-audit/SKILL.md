---
name: prolactin-code-audit
description: Use whenever the user asks for a code audit, code review, or "audit" of PROLACTIN code, or wants a file/module/paradigm checked for issues before a major phase or refactor. Systematically scans for this project's known issue classes — garbage characters, dead code, O(n^2) patterns, missing guards, RNG misuse, calibration-guard gaps, audio/convolution errors, MultiThreshold spec deviations, and Mac/Windows portability — and reports severity-ranked findings without fixing them unless asked.
---

# PROLACTIN — Code Audit

Mirrors the prior audit docs (`code_audit_2026-02-14.md`,
`code_audit_2026-02-19.md`, `audit_supplement_2026-02-19.md`). Read only the
files in scope plus `project_file_manifest.md`; don't graze the whole repo.

## Output

Severity-ranked findings (high → low). Per finding: file, location (line or
method), what's wrong, why it matters, suggested fix. **Flag, don't fix** —
this is a review pass. Respect Eric's minimal-diff rule: never propose
out-of-scope rewrites. If asked to fix afterward, fix only the flagged items.

## Checklist (by category)

### Encoding
- Non-ASCII garbage chars (`Ã Â â€ â†'` etc.). `grep -nP '[^\x00-\x7F]'`.
  Arrows/Greek/math in comments must be real UTF-8, not mojibake.

### Dead / broken code
- Unused methods or imports (precedent: dead `update_streaks_and_difficulty`).
- Inline imports that belong at top level.
- Module-level instantiation triggering side effects on import (e.g. an
  `EventGen()`/audio-init at import time must be behind `if __name__ == "__main__":`).
- Import-path / package-layout inconsistencies (`utils/`, `config/`, flat) and
  `utils/__init__.py` eager-import circular-import landmines.

### Performance
- O(n^2) in loops, esp. `pd.concat` per-trial → use a list accumulator.

### Guards & invariants
- `hasattr` guards for `self.fc` / `self.fm` / `self.noise_level` in
  `prepare_trial()`.
- Calibration is HARD-required: paradigms must raise (not silently fall back)
  if no `CalibrationManager` — no uncalibrated path.
- RNG initialized ONCE at `__init__` (`self._rng = np.random.default_rng()`),
  never per-trial (per-trial → clustered/biased draws).

### Audio correctness
- FIR convolution `mode='full'`, never `mode='same'` (`same` clicks onset and
  kills the tail).
- `core.wait()` must be ringout-aware: `+ ringout + 0.1`, not flat `+ 0.1`.
- PTB `sound.Sound` objects need explicit `.stop()` after `core.wait()` (else
  premature GC → macOS segfault).
- ITD bypasses TrialPlayer BY DESIGN (per-channel timing ≠ per-channel gain) —
  not a bug.
- ILD uses two separate `spl_to_amplitude()` calls routed through TrialPlayer
  (don't bake L/R asymmetry into the stereo array — that discards per-ear
  sensitivity correction).
- dB SPL paradigms: `amp=1.0` with `per_channel_gain=(amp_L, amp_R)`.

### Adaptive logic
- Conforms to the modified MultiThreshold adaptive pattern (reference:
  `multithreshold_matlab_reference.md`, `MultiThreshold_Users_Manual_ZH.pdf`,
  `Lecluyse2013IJAprofiles.pdf`). Check step sizes, reversals, catch-trial
  handling against spec before calling a deviation a bug — some are intentional
  simplifications (e.g. PROLACTIN's yes/no vs the two-interval counting task).

### Portability
- Runs on both macOS and Windows (device-name substring matching, path
  handling, no OS-specific assumptions).

### Known open bug to watch
- FM modulation index: `mod_ind` as percent vs radians/β is a long-standing
  unresolved item. Flag if touched; don't silently "fix" — needs team + ref
  toolbox comparison.

## Before claiming a spec deviation

Verify against the primary reference doc, not memory. Confident claims about
MultiThreshold behavior or UI/menu paths have been wrong before.
