---
name: prolactin-session-cleanup
description: Run at the END of any PROLACTIN development session. Use whenever the user says "wrap up" / "session cleanup" / "we're done" / "end of session", or asks for a changelog or git commit message in the PROLACTIN project. Produces the session changelog FILE (key signatures, files-modified table, open issues) plus a concise git commit message shown in chat, and runs the ASCII / garbage-character check on every file touched this session.
---

# PROLACTIN — Session Cleanup

Bookend to `prolactin-session-start`. Three deliverables: changelog file,
commit message (chat only), garbage-char sweep.

## 1. Garbage-character sweep (do this FIRST, before finalizing files)

Grep every file touched this session for non-ASCII artifacts. Common ones this
project has hit: `Ã`, `Â`, `â€`, `â€™`, `â€"`, `â†'`, mojibake of `→ θ μ ± —`.

```bash
grep -nP '[^\x00-\x7F]' <file>      # any non-ASCII byte
```

Expected legitimate use is essentially none — source files are ASCII-only by
convention; arrows/Greek/math in comments must be real UTF-8 (`→ θ μ ± —`), not
mojibake. **If artifacts are present, I introduced them in an earlier edit — fix
them and say so. Never tell Eric he added them.** He has caught this exact
misattribution before; don't repeat it.

## 2. Changelog file

`session_changelog_YYYY-MM-DD[_session_NN].md`, following the established format:

- **Session start protocol (next session)** — 3-line reminder: push local copies,
  verify the signatures below, review Open Issues.
- **High-level summary** — what changed and why, a few sentences.
- **Work completed** — per file, what changed.
- **Files modified table** — `| File | Change |`, PLUS an explicit
  "Files NOT modified:" line. The not-modified list matters to Eric.
- **Key Signatures** — per changed file, a grep-able string (code line, method
  signature, distinctive comment) that proves the file is the new version.
  These are what next session's start-check greps for, so pick lines that are
  unique and unlikely to drift.
- **Open Issues / Next Steps** — carry forward the prior list, add/remove as needed.

Save to `/mnt/user-data/outputs/` and present it.

## 3. Git commit message (chat only — do NOT write a file)

Small research team → concise. Imperative subject, optional short body bullets
only if the change isn't self-explanatory. Display inline in the chat.

## 4. Re-upload reminder

End by listing the exact files Eric needs to re-upload into the project (the
changed ones + the new changelog), so next session's start-check passes.
