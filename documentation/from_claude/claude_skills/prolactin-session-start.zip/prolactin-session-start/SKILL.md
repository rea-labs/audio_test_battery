---
name: prolactin-session-start
description: Run this at the very START of any PROLACTIN development session, before any other work. Use whenever a new chat opens in the PROLACTIN project, the user says "starting a session" / "let's continue" / "new session", references the PROLACTIN project, or asks for any code or file work in it. Verifies the project files are current against the latest session changelog's key signatures, and CRUCIALLY pauses to let the user upload fresh local copies before continuing. Do not skip this even if the user jumps straight to a task.
---

# PROLACTIN — Session Start

The single most important behavior: **pause and let Eric upload before continuing.**
Eric has repeatedly seen this check run as the first output and then the assistant
plow ahead without giving him a chance to push his local working copies. Don't.

## Procedure (in order)

1. **Announce.** One line: "Running PROLACTIN session-start check."

2. **Remind to upload.** Tell Eric to push his local working copies into the
   project now, before anything else.

3. **Read only the latest changelog.** Find the most recent
   `session_changelog_*.md` by the date (and `_session_NN`) in the filename.
   Read THAT one only. If it says prior changelogs "still apply," skim the one
   it points to for additional signatures. Do NOT read all changelogs, PRDs, or
   audit docs — that is the context bloat this project is trying to avoid. See
   `project_file_manifest.md` for what each file is and whether it's worth opening.

4. **Verify key signatures.** The latest changelog has a "Key Signatures" (or
   "How to verify at session start") section listing a grep-able string per
   changed file. For each, search the corresponding project file for that string.

5. **DECISION — this is the branch point:**
   - **Any signature missing → STOP.** List exactly which files are stale and
     the signature each is missing. Tell Eric to re-upload those specific files.
     Do NOT proceed to the requested task. Wait for him.
   - **All signatures present → say so** ("All key signatures verified, files
     current") and continue with whatever Eric asked.

## Caching-lag gotcha

If a signature check fails *immediately after* Eric just uploaded the file, the
likely cause is `/mnt/project/` cache lag, NOT a genuinely stale file. Don't
declare the file outdated. Ask Eric to attach the file directly in chat so it's
read from `/mnt/user-data/uploads/` instead, and re-verify against that.

## Notes

- Keep it tight. This is a gate, not a report.
- Don't read code files you don't need to check a signature against.
