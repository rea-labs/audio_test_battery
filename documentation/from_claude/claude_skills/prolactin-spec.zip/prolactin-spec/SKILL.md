---
name: prolactin-spec
description: Use BEFORE writing or generating any new or modified PROLACTIN file or feature. Whenever the user proposes a code change, new feature, bug fix, or edit in the PROLACTIN project and the details aren't fully pinned down, run this: first GRILL the user with project-specific clarifying questions, then produce a CONCISE PRD before any code is written. Strategy before code — don't start coding off a half-specified request.
---

# PROLACTIN — Spec (Grill → PRD)

Two phases. Don't write code until the PRD is approved. Eric explicitly wants
strategy and open questions surfaced before implementation, and would rather be
asked than have the assistant guess.

## Phase 1 — Grill

Pin down the request. Use the interactive option-prompt tool when it speeds
things up (tappable choices beat typing on mobile). Prefer one focused question
at a time unless batching is clearly faster. Project-specific dimensions to probe:

- **Scope boundary.** Exactly which files/methods are in scope, and what is
  explicitly OUT. Eric enforces "no out-of-scope changes" hard — get the fence
  drawn before coding.
- **Base vs subclass.** Is this a change to `AdaptiveParadigm` (affects all
  paradigms) or a single paradigm? What's the blast radius?
- **Calibration impact.** Does it touch `spl_to_amplitude()`, `per_channel_gain`,
  the TrialPlayer path, or the hard calibration guard? (Most level-related
  changes do.)
- **MultiThreshold adherence.** Does it follow the modified adaptive logic
  pattern? Any intentional deviation from the reference, and is it documented?
- **Portability.** Any macOS/Windows-specific concern (paths, device names,
  PTB/GC behavior)?
- **OOP / drop-in.** Does it preserve the clean structure so future swaps (e.g.
  tkinter → NiceGUI participant GUI, the ExperimentController refactor) drop in
  cleanly?
- **Incremental vs rewrite.** Default to the smallest viable diff. Push back if
  the request implies a rewrite where a patch would do.
- **Testing / headless.** Implications for test scripts, MockParticipant,
  `headless=True`?

If anything stays unclear after grilling, ask — don't fill the gap with an
assumption.

## Phase 2 — PRD

Write a concise PRD (`prd_YYYY-MM-DD[_pass].md`), matching the existing PRD
format. Sacrifice grammar for concision. Include:

- **Goal** — one or two lines.
- **Implementation, per file** — what changes where; integration points.
- **Key signatures** — the grep-able strings that will mark the new versions
  (feeds straight into session-cleanup's changelog).
- **Out of scope** — explicit, mirroring the scope fence from Phase 1.
- **Suggested implementation order** — short table if multi-step.
- **Open questions** — list at the end, unresolved items for Eric to answer.

For major design phases, add an explicit adversarial review of high-severity
risks before proceeding.

Save the PRD to `/mnt/user-data/outputs/`, present it, and stop. Wait for
approval before writing implementation code.
